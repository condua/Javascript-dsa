const { solve } = require("../squarest_game_puzzle");

// prettier-ignore
console.log(
  solve(100, [
    40, 40,
    39, 39,
    24, 24, 24, 24,
    23, 23, 23, 23,
    17, 17, 17, 17, 17,
    16, 16, 16, 16, 16, 16
  ])
);

/*
  A new algorithm that works with repeatable options
*/
