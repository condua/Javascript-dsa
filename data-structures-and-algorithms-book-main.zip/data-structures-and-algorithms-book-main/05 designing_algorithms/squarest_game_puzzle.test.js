const { solve } = require("./squarest_game_puzzle");

console.log(solve(50, [15, 9, 30, 21, 19, 3, 12, 6, 25, 27]));
