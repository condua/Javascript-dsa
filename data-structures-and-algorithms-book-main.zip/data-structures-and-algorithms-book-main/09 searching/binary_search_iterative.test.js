const binarySearch = require("./binary_search_recursive");
const checkSearch = require("./check_search");

checkSearch(binarySearch, true);
