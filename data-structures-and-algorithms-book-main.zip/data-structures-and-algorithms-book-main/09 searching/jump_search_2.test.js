const jumpSearch = require("./jump_search_2");
const checkSearch = require("./check_search");

checkSearch(jumpSearch, true);
