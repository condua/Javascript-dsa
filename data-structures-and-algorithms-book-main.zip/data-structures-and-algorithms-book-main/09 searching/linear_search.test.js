const linearSearch = require("./linear_search");
const checkSearch = require("./check_search");

checkSearch(linearSearch, false);
