const jumpSearch = require("./jump_search_3");
const checkSearch = require("./check_search");

checkSearch(jumpSearch, true);
