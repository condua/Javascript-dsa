const interpolationSearch = require("./interpolation_search");
const checkSearch = require("./check_search");

checkSearch(interpolationSearch, true);
