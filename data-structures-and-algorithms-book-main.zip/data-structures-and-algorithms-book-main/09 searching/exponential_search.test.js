const exponentialSearch = require("./exponential_search");
const checkSearch = require("./check_search");

checkSearch(exponentialSearch, true);
