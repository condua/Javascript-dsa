module.exports = {
  arrowParens: "always",
  bracketSpacing: true,
  printWidth: 78,
  semi: true,
  singleQuote: false,
  tabWidth: 2,
  trailingComma: "none",
  useTabs: false
};
