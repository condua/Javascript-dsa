const user = {
  firstName: "Abraham",
  lastName: "Lincoln",
  role: "President"
};

console.log(user.name);
