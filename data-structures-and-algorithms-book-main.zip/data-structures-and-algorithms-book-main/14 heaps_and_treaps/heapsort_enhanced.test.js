const { heapsort_enhanced } = require("./heapsort_enhanced.js");

console.log(heapsort_enhanced([9, 22, 60, 34, 24, 40, 4, 12, 56, 11]));
