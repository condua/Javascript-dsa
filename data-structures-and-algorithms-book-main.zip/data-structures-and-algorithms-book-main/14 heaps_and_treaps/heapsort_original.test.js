const { heapsort_original } = require("./heapsort_original.js");

console.log(heapsort_original([9, 22, 60, 34, 24, 40, 4, 12, 56, 11]));
